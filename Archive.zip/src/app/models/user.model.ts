export interface User {
  id: number;
  name: string;
  department: string;
  phone: string;
  address: string;
  pincode: string;
}
