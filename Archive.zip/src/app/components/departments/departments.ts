import { Component } from '@angular/core';

@Component({
  selector: 'app-departments',
  standalone: true,
  templateUrl: './departments.html',
  styleUrls: ['./departments.css']
})
export class DepartmentsComponent {}
